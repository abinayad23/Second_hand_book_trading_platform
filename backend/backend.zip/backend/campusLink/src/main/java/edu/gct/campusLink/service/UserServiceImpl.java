package edu.gct.campusLink.service;

import edu.gct.campusLink.bean.User;
import edu.gct.campusLink.bean.AuthRequest;
import edu.gct.campusLink.dao.UserRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final BCryptPasswordEncoder passwordEncoder;
    private final OtpService otpService;

    public UserServiceImpl(UserRepository userRepository, OtpService otpService) {
        this.userRepository = userRepository;
        this.otpService = otpService;
        this.passwordEncoder = new BCryptPasswordEncoder();
    }

    @Override
    public String initiateRegistration(AuthRequest request) {
        if (Boolean.TRUE.equals(request.getIsFirstYear())) {
            // First-year → OTP to mobile
            if (request.getPhone() == null || request.getPhone().isBlank()) {
                throw new IllegalArgumentException("Mobile number is required for first-year users");
            }
            return otpService.generateOtp(request.getPhone());
        } else {
            // Not first-year → OTP to email
            if (request.getEmail() == null || !request.getEmail().contains("@")) {
                throw new IllegalArgumentException("Valid email is required for non–first-year users");
            }
            return otpService.generateOtp(request.getEmail());
        }
    }

    @Override
    public User completeRegistration(AuthRequest request, String enteredOtp) {
    	Boolean isFirstYear = request.getIsFirstYear();
        String otpKey = isFirstYear ? request.getPhone() : request.getEmail();
    	if (!otpService.validateOtp(otpKey, enteredOtp)) {
            throw new IllegalArgumentException("Invalid OTP");
        }

        User user = new User();
        user.setName(request.getName());
        user.setEmail(request.getEmail());
        user.setDepartment(request.getDepartment());
        user.setPhone(request.getPhone());
        user.setLocation(request.getLocation());
        user.setDateOfBirth(request.getDateOfBirth());
        user.setIsFirstYear(request.getIsFirstYear());
        user.setRegisterNumber(request.getRegisterNumber());
        user.setIsVerified(true);

        if (request.getIsFirstYear()) {
            user.setUsername(request.getRegisterNumber());
        } else {
            user.setUsername(request.getEmail());
        }

        user.setPassword(passwordEncoder.encode(request.getDateOfBirth().toString()));
        return userRepository.save(user);
    }

    @Override
    public Optional<User> getUserById(Long id) {
        return userRepository.findById(id);
    }
    
    @Override
    public Optional<User> getUserByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    @Override
    public User updateUser(Long id, User updatedUser) {
        User user = userRepository.findById(id).orElseThrow();
        user.setName(updatedUser.getName());
        user.setDepartment(updatedUser.getDepartment());
        user.setPhone(updatedUser.getPhone());
        user.setLocation(updatedUser.getLocation());
        user.setProfileImagePath(updatedUser.getProfileImagePath());
        return userRepository.save(user);
    }

    @Override
    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }

    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }
}