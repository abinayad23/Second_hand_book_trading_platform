package edu.gct.campusLink.service;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class OtpService {
    private final Map<String, String> otpStore = new ConcurrentHashMap<>();

    public String generateOtp(String key) {
        String otp = String.valueOf(new Random().nextInt(900000) + 100000);
        otpStore.put(key, otp);

        if (key.contains("@")) {
            System.out.println("OTP sent to EMAIL: " + key + " → " + otp);
        } else {
            System.out.println("OTP sent to MOBILE: " + key + " → " + otp);
        }

        return otp;
    }

    public boolean validateOtp(String email, String enteredOtp) {
        return otpStore.containsKey(email) && otpStore.get(email).equals(enteredOtp);
    }
}