package edu.gct.campusLink.controller;

import edu.gct.campusLink.bean.AuthRequest;
import edu.gct.campusLink.bean.User;
import edu.gct.campusLink.service.JwtService;
import edu.gct.campusLink.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;
    private final AuthenticationManager authenticationManager;
    private final JwtService jwtService;

    public UserController(UserService userService, AuthenticationManager authenticationManager, JwtService jwtService) {
        this.userService = userService;
        this.authenticationManager = authenticationManager;
        this.jwtService = jwtService;
    }

    @PostMapping("/initiate")
    public String initiate(@RequestBody AuthRequest request) {
        return userService.initiateRegistration(request);
    }

    @PostMapping("/verify")
    public User verifyOtpAndRegister(@RequestBody AuthRequest request, @RequestParam String otp) {
        return userService.completeRegistration(request, otp);
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody AuthRequest request) {
        try {
            authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
            );

            User user = userService.getUserByEmail(request.getEmail())
            	    .orElseThrow(() -> new RuntimeException("User not found"));
            String token = jwtService.generateToken(user);

            return ResponseEntity.ok(new LoginResponse(token, user.getUsername(), user.getRole()));
        } catch (AuthenticationException e) {
            return ResponseEntity.status(401).body("Invalid email or password");
        }
    }

    @GetMapping("/{id}")
    public User getUser(@PathVariable Long id) {
        return userService.getUserById(id).orElseThrow();
    }

    @PutMapping("/{id}/edit")
    public User editProfile(@PathVariable Long id, @RequestBody User updatedUser) {
        return userService.updateUser(id, updatedUser);
    }

    @DeleteMapping("/{id}")
    public void deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
    }

    @GetMapping
    public List<User> getAllUsers() {
        return userService.getAllUsers();
    }
    
    @GetMapping("/test")
    public String testAuth() {
        return "Authenticated as: " + SecurityContextHolder.getContext().getAuthentication().getName();
    }

    // DTO for login response
    public static class LoginResponse {
        public String token;
        public String username;
        public String role;

        public LoginResponse(String token, String username, String role) {
            this.token = token;
            this.username = username;
            this.role = role;
        }
    }
}