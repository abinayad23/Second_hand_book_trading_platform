package edu.gct.campusLink;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CampusLinkApplication {
    public static void main(String[] args) {
        SpringApplication.run(CampusLinkApplication.class, args);
    }
}